package sjm.parse.tokens;

import java.math.BigDecimal;
import java.util.*;
import sjm.parse.*;

/*
 * Copyright (c) 2009 Johannes Link. All Rights Reserved.
 */

/**
 * A DecimalNum matches a number from a token assembly and converts it into a BigDecimal.
 */

public class DecimalNum extends Terminal {

	/**
	 * Returns true if an assembly's next element is a number.
	 *
	 * @param   object   an element from an assembly
	 *
	 * @return   true, if an assembly's next element is a number as
	 *           recognized the tokenizer
	 */
	protected boolean qualifies(Object o) {
		Token t = (Token) o;
		return t.isNumber();
	}

	/**
	 * Create a set with one random number (between 0 and 
	 * 100).
	 */
	public Vector randomExpansion(int maxDepth, int depth) {
		BigDecimal d = new BigDecimal(Math.floor(1000.0 * Math.random()) / 10);
		Vector v = new Vector();
		v.addElement(d.toPlainString());
		return v;
	}

	/**
	 * Returns a textual description of this parser.
	 *
	 * @param   vector   a list of parsers already printed in 
	 *                   this description
	 * 
	 * @return   string   a textual description of this parser
	 *
	 * @see Parser#toString()
	 */
	public String unvisitedString(Vector visited) {
		return "DecimalNum";
	}
}
